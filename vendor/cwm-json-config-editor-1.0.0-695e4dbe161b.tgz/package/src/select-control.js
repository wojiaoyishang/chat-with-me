import { installFormControlStyles } from './text-editor.js';
let sequence = 0;

/** Accessible, styled listbox while preserving native values and change events. */
export function createSelectControl(input) {
  const doc = input.ownerDocument, win = doc.defaultView;
  installFormControlStyles(doc);
  const root = doc.createElement('div'), trigger = doc.createElement('button'), caption = doc.createElement('span'), chevron = doc.createElement('i');
  root.className = 'cwm-select-control'; trigger.type = 'button'; trigger.className = 'cwm-select-trigger';
  trigger.setAttribute('role', 'combobox'); trigger.setAttribute('aria-haspopup', 'listbox'); trigger.setAttribute('aria-expanded', 'false');
  trigger.setAttribute('aria-label', input.getAttribute('aria-label') || '请选择'); chevron.textContent = '⌄'; chevron.setAttribute('aria-hidden', 'true');
  trigger.append(caption, chevron);
  input.classList.add('cwm-select-native'); input.tabIndex = -1; input.setAttribute('aria-hidden', 'true');
  root.append(input, trigger);
  let popup = null, activeIndex = 0, destroyed = false, query = '', queryAt = 0;
  const id = `cwm-select-${++sequence}`;
  const options = () => [...input.options];
  function position() {
    if (!popup) return;
    const rect = trigger.getBoundingClientRect(), viewportWidth = win.innerWidth, viewportHeight = win.innerHeight;
    const width = Math.min(Math.max(160, rect.width), viewportWidth - 16);
    const below = viewportHeight - rect.bottom - 12, above = rect.top - 12;
    const height = Math.min(260, Math.max(below >= 150 || below >= above ? below : above, 64));
    popup.style.width = `${width}px`; popup.style.maxHeight = `${height}px`;
    popup.style.left = `${Math.max(8, Math.min(rect.left, viewportWidth - width - 8))}px`;
    const actualHeight = popup.getBoundingClientRect().height || Math.min(height, options().length * 31 + 8);
    popup.style.top = `${below >= actualHeight || below >= above ? rect.bottom + 4 : Math.max(8, rect.top - actualHeight - 4)}px`;
  }
  function highlight(index) {
    const list = options(); if (!list.length || !popup) return;
    activeIndex = (index + list.length) % list.length;
    const entries = [...popup.children];
    entries.forEach((entry, i) => entry.dataset.highlighted = String(i === activeIndex));
    popup.setAttribute('aria-activedescendant', entries[activeIndex]?.id || '');
    entries[activeIndex]?.scrollIntoView?.({ block: 'nearest' });
  }
  function choose(index) {
    const option = options()[index]; if (!option || option.disabled) return;
    input.value = option.value; input.dispatchEvent(new win.Event('change', { bubbles: true })); close(true);
  }
  function populate() {
    if (!popup) return;
    popup.replaceChildren();
    options().forEach((option, index) => {
      const entry = doc.createElement('div'), text = doc.createElement('span'), check = doc.createElement('i');
      entry.className = 'cwm-select-option'; entry.id = `${id}-option-${index}`; entry.setAttribute('role', 'option');
      entry.dataset.value = option.value; entry.setAttribute('aria-selected', String(option.selected)); entry.setAttribute('aria-disabled', String(option.disabled));
      text.textContent = option.textContent; check.textContent = option.selected ? '✓' : ''; check.setAttribute('aria-hidden', 'true');
      entry.append(text, check); entry.addEventListener('pointermove', () => { if (!option.disabled) highlight(index); }); entry.addEventListener('click', () => choose(index));
      popup.append(entry);
    });
    position(); highlight(Math.max(0, input.selectedIndex));
  }
  function close(restore = false) {
    popup?.remove(); popup = null; trigger.setAttribute('aria-expanded', 'false'); trigger.removeAttribute('aria-controls');
    if (restore && trigger.isConnected) trigger.focus({ preventScroll: true });
  }
  function keyboard(event) {
    const list = options();
    if (['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' ', 'Escape'].includes(event.key)) { event.preventDefault(); event.stopPropagation(); }
    if (event.key === 'Escape') { close(true); return; }
    if (event.key === 'Tab') { close(); return; }
    if (!popup && ['Enter', ' ', 'ArrowDown', 'ArrowUp'].includes(event.key)) { open(); return; }
    if (!popup) return;
    if (event.key === 'Enter' || event.key === ' ') { choose(activeIndex); return; }
    const delta = event.key === 'ArrowUp' ? -1 : 1;
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      let next = event.key === 'Home' ? 0 : event.key === 'End' ? list.length - 1 : activeIndex + delta;
      for (let count = 0; count < list.length; count++, next += delta) { const index = (next + list.length) % list.length; if (!list[index].disabled) { highlight(index); break; } }
    } else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey) {
      query = Date.now() - queryAt > 700 ? event.key : query + event.key; queryAt = Date.now();
      const index = list.findIndex(option => !option.disabled && option.textContent.toLowerCase().startsWith(query.toLowerCase()));
      if (index >= 0) highlight(index);
    }
  }
  function open() {
    if (destroyed || input.disabled || popup) return;
    popup = doc.createElement('div'); popup.className = 'cwm-select-popover pretty-scrollbar'; popup.id = id; popup.tabIndex = -1;
    popup.setAttribute('role', 'listbox'); popup.setAttribute('aria-label', trigger.getAttribute('aria-label'));
    const owner = root.closest('dialog[open]') || doc.body; owner.append(popup);
    trigger.setAttribute('aria-controls', id); trigger.setAttribute('aria-expanded', 'true');
    popup.addEventListener('keydown', keyboard); populate(); popup.focus({ preventScroll: true });
  }
  function refresh() { if (destroyed) return; caption.textContent = input.selectedOptions[0]?.textContent || '请选择'; trigger.disabled = input.disabled; if (input.disabled) close(); else populate(); }
  const toggle = () => popup ? close(true) : open();
  const outside = event => { if (!root.contains(event.target) && !popup?.contains(event.target)) close(); };
  const observer = new win.MutationObserver(refresh); observer.observe(input, { childList: true, subtree: true, attributes: true });
  trigger.addEventListener('click', toggle); trigger.addEventListener('keydown', keyboard); input.addEventListener('change', refresh);
  doc.addEventListener('pointerdown', outside, true); win.addEventListener('resize', position); doc.addEventListener('scroll', position, true);
  const api = { root, trigger, isOpen: () => Boolean(popup), contains: target => root.contains(target) || Boolean(popup?.contains(target)),
    close, destroy() { if (destroyed) return; destroyed = true; close(); observer.disconnect(); trigger.removeEventListener('click', toggle); trigger.removeEventListener('keydown', keyboard); input.removeEventListener('change', refresh); doc.removeEventListener('pointerdown', outside, true); win.removeEventListener('resize', position); doc.removeEventListener('scroll', position, true); root.remove(); } };
  root._cwmSelectControl = api; refresh(); return api;
}
