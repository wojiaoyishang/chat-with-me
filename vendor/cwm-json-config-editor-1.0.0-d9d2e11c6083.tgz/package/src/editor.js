import { EditorState, Compartment } from '@codemirror/state';
import { EditorView, keymap, lineNumbers, drawSelection, highlightActiveLine } from '@codemirror/view';
import { history, historyKeymap, defaultKeymap, indentWithTab } from '@codemirror/commands';
import { json } from '@codemirror/lang-json';
import { syntaxHighlighting, defaultHighlightStyle, foldGutter, foldKeymap, bracketMatching } from '@codemirror/language';
import { searchKeymap, search } from '@codemirror/search';
import { lintGutter, setDiagnostics } from '@codemirror/lint';
import { EditorModel, clone, getAt, setAt, kind, types, seed, pointer, nodeOffset } from './model.js';
import stylesheet from './editor.css';
import { createMultilineEditor } from './text-editor.js';
export { createMultilineEditor, installFormControlStyles } from './text-editor.js';
export { createSelectControl } from './select-control.js';
export { EditorModel, parse, validate, kind, seed } from './model.js';

const typeLabels = { string: '文本', number: '数字', integer: '整数', boolean: '布尔值', null: 'null', object: '对象', array: '列表' };
let nextEditorId = 0;
function schemaTypes(spec) {
  return spec.type ? (Array.isArray(spec.type) ? spec.type : [spec.type]) : spec.enum?.length ? [...new Set(spec.enum.map(kind))] : types;
}
function ownSpec(spec, key) { return spec.properties?.[key] || (typeof spec.additionalProperties === 'object' ? spec.additionalProperties : {}); }
export function validateEditors(container) {
  for (const host of container.querySelectorAll('.cwm-json-editor')) {
    if (!host.closest('[hidden]') && !host._cwmJsonEditor?.readOnly) host._cwmJsonEditor?.getValue();
  }
}

export function mount(host, options = {}) {
  const doc = host.ownerDocument;
  if (!doc.getElementById('cwm-json-editor-style')) {
    const style = doc.createElement('style'); style.id = 'cwm-json-editor-style'; style.textContent = stylesheet; doc.head.append(style);
  }
  const model = new EditorModel(options);
  let config = options, view = null, syncing = false, destroyed = false, disposers = [], localErrors = new Map();
  const pendingKeys = new Map();
  let mode = options.defaultMode === 'json' || !model.valid ? 'json' : 'form';
  const readOnlyCompartment = new Compartment();
  host.classList.add('cwm-json-editor');
  function element(tag, text, className) { const node = doc.createElement(tag); if (text != null) node.textContent = text; if (className) node.className = className; return node; }
  function button(text, callback, title = text) { const node = element('button', text); node.type = 'button'; node.title = title; node.setAttribute('aria-label', title); node.addEventListener('click', callback); return node; }
  const toolbar = element('div', null, 'cje-toolbar'), tabs = element('div', null, 'cje-tabs');
  tabs.setAttribute('role', 'tablist'); tabs.setAttribute('aria-label', '编辑模式');
  const formTab = button('配置', () => switchMode('form')), sourceTab = button('JSON', () => switchMode('json'));
  [formTab, sourceTab].forEach((tab) => tab.setAttribute('role', 'tab'));
  tabs.append(formTab, sourceTab);
  const formatButton = button('格式化', format, '格式化 JSON · Alt+Shift+F');
  toolbar.append(tabs, formatButton, element('span', 'JSON 模式：查找 Ctrl+F · 撤销 Ctrl+Z', 'cje-hint'));
  const conflict = element('div', null, 'cje-conflict'), form = element('div', null, 'cje-form'), source = element('div', null, 'cje-source');
  const errors = element('div', null, 'cje-errors'), status = element('div', null, 'cje-status');
  const id = `cje-${++nextEditorId}`;
  form.id = `${id}-form`; source.id = `${id}-source`;
  form.setAttribute('role', 'tabpanel'); source.setAttribute('role', 'tabpanel');
  formTab.setAttribute('aria-controls', form.id); sourceTab.setAttribute('aria-controls', source.id);
  errors.setAttribute('role', 'status'); errors.setAttribute('aria-live', 'polite');
  conflict.hidden = true; host.replaceChildren(toolbar, conflict, form, source, errors, status);

  function allErrors() { return [...model.errors, ...localErrors.values()]; }
  function announce(userChanged = false) {
    const issues = allErrors();
    host.dataset.valid = String(!issues.length);
    errors.hidden = !issues.length; errors.replaceChildren();
    for (const issue of issues.slice(0, 8)) {
      let location = issue.path || 'JSON';
      if (issue.offset !== undefined) {
        const before = model.draft.slice(0, issue.offset).split('\n'); location = `第 ${before.length} 行，第 ${before.at(-1).length + 1} 列`;
      }
      errors.append(button(`${location}：${issue.message}`, () => {
        if (mode === 'json') { const offset = Math.min(issue.offset ?? nodeOffset(model.tree, (issue.path || '').split('/').slice(1).map((key) => key.replace(/~1/g, '/').replace(/~0/g, '~'))), view.state.doc.length); view.dispatch({ selection: { anchor: offset }, scrollIntoView: true }); view.focus(); }
        else { const target = [...form.querySelectorAll('[data-pointer]')].find((node) => node.dataset.pointer === issue.path); target?.querySelector('input,select,button')?.focus(); }
      }));
    }
    status.textContent = issues.length ? `${issues.length} 处待修正；草稿已保留，修正后可保存。` : '校验通过 · 文本、数字、布尔值和 null 按各自类型保存';
    for (const node of form.querySelectorAll('[data-pointer]')) node.classList.toggle('cje-invalid', issues.some((issue) => issue.path === node.dataset.pointer));
    if (view && mode === 'json') {
      const diagnostics = issues.map((issue) => { const from = Math.min(issue.offset ?? nodeOffset(model.tree, (issue.path || '').split('/').slice(1).map((key) => key.replace(/~1/g, '/').replace(/~0/g, '~'))), view.state.doc.length); return { from, to: Math.min(from + 1, view.state.doc.length), severity: 'error', message: issue.message }; });
      view.dispatch(setDiagnostics(view.state, diagnostics));
    }
    const state = { ...model.state(), errors: issues, valid: !issues.length, pendingKeys: [...pendingKeys.values()], userChanged };
    config.onStateChange?.(state);
    host.dispatchEvent(new doc.defaultView.CustomEvent('cwm-json-editor-state', { bubbles: true, detail: state }));
  }
  function publish() {
    config.onDraftChange?.(model.draft);
    if (model.valid && !localErrors.size) config.onChange?.(clone(model.value));
    announce(true);
  }
  function syncSource() { if (view && view.state.doc.toString() !== model.draft) { syncing = true; view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: model.draft } }); syncing = false; } }
  function commit(path, value, rebuild = false, remove = false) {
    if (config.readOnly) return;
    localErrors.delete(pointer(path));
    if (remove) for (const key of localErrors.keys()) if (key.startsWith(pointer(path) + '/')) localErrors.delete(key);
    if (rebuild && (localErrors.size || pendingKeys.size)) { announce(); return; }
    model.commit(setAt(model.value, path, value, remove)); syncSource();
    if (rebuild) renderForm(); publish();
  }
  function fail(path, message) { localErrors.set(pointer(path), { path: pointer(path), message }); announce(true); }
  function chooseType(spec, current, callback) {
    const select = element('select', null, 'cje-type'); select.setAttribute('aria-label', '值类型');
    for (const type of schemaTypes(spec)) { const option = element('option', typeLabels[type] || type); option.value = type; select.append(option); }
    select.value = current === 'number' && schemaTypes(spec).includes('integer') ? 'integer' : current;
    select.dataset.fixed = String(select.options.length <= 1);
    select.disabled = config.readOnly || select.options.length <= 1;
    select.addEventListener('change', () => callback(select.value)); return select;
  }
  function renderNode(path, spec = {}, ui = {}, depth = 0, label = undefined) {
    const value = getAt(model.value, path), current = kind(value), node = element('div', null, 'cje-node');
    node.dataset.kind = current;
    node.dataset.fixedType = String(schemaTypes(spec).length <= 1);
    node.dataset.pointer = path.length ? pointer(path) : '';
    const row = element('div', null, 'cje-row'), heading = element('span', label || spec.title || String(path.at(-1) ?? '值'), 'cje-label');
    if (spec.description) heading.append(element('small', spec.description));
    row.append(heading, chooseType(spec, current, (type) => commit(path, seed({ ...spec, default: undefined, enum: undefined, type }, type), true)));
    node.append(row);
    const widgetName = ui.widget || spec.ui?.widget;
    if (config.widgets && Object.hasOwn(config.widgets, widgetName) && typeof config.widgets[widgetName] === 'function') {
      const result = config.widgets[widgetName]({ doc, value, path, schema: spec, readOnly: config.readOnly, getValue: () => model.value, onError: (message) => fail(path, message), onChange: (next) => commit(path, next) });
      row.append(result.element || result); if (result.destroy) disposers.push(result.destroy); return node;
    }
    if (spec.enum && !['object', 'array'].includes(current)) {
      const select = element('select', null, 'cje-value');
      spec.enum.forEach((item, index) => { const option = element('option', spec.enumNames?.[index] || String(item)); option.value = String(index); select.append(option); });
      select.value = String(spec.enum.findIndex((item) => JSON.stringify(item) === JSON.stringify(value)));
      select.disabled = config.readOnly; select.setAttribute('aria-label', label || spec.title || '值');
      select.addEventListener('change', () => { const next = clone(spec.enum[Number(select.value)]); commit(path, next, kind(next) !== current); }); row.append(select);
    } else if (current === 'boolean') {
      const input = element('input'); input.type = 'checkbox'; input.checked = value; input.disabled = config.readOnly; input.setAttribute('aria-label', label || spec.title || '布尔值');
      input.addEventListener('change', () => commit(path, input.checked)); row.append(input);
    } else if (current === 'null') row.append(element('span', 'null', 'cje-null'));
    else if (!['object', 'array'].includes(current)) {
      const input = element(current === 'string' && (ui.multiline || spec.ui?.multiline || String(value).includes('\n')) ? 'textarea' : 'input', null, 'cje-value');
      input.value = value ?? ''; input.disabled = config.readOnly; input.setAttribute('aria-label', label || spec.title || '值'); input.placeholder = ui.placeholder || spec.ui?.placeholder || '';
      if (current === 'number') input.inputMode = 'decimal';
      input.addEventListener('input', () => {
        const text = input.value;
        if (current === 'number') {
          if (!/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(text)) { fail(path, '请输入完整的 JSON 数字'); return; }
          const number = Number(text);
          if (!Number.isFinite(number) || (Number.isInteger(number) && !Number.isSafeInteger(number))) { fail(path, '数字超出安全范围'); return; }
          commit(path, number);
        } else commit(path, text);
      });
      if (input.tagName === 'TEXTAREA') {
        const editor = createMultilineEditor({ input, label: label || spec.title || '文本', readOnly: config.readOnly });
        row.append(editor.root); disposers.push(() => editor.destroy());
      } else row.append(input);
    } else {
      if (depth >= (config.maxFormDepth || 5)) {
        row.append(button('在 JSON 中编辑此层', () => { switchMode('json'); if (view) { const from = nodeOffset(model.tree, path); view.dispatch({ selection: { anchor: from }, scrollIntoView: true }); view.focus(); } }));
        return node;
      }
      const array = current === 'array', details = element('details'), summary = element('summary', `${array ? value.length + ' 项' : Object.keys(value).length + ' 个字段'}`, 'cje-summary');
      const children = element('div', null, 'cje-children'); details.open = depth < 2; details.append(summary, children); node.append(details);
      let rendered = false;
      function fill() {
        if (rendered) return; rendered = true;
        const entries = Object.entries(value);
        for (const [key, child] of entries) {
          const entryPath = [...path, array ? Number(key) : key], childSpec = array ? (spec.items || {}) : ownSpec(spec, key);
          const childUi = array ? (ui.items || {}) : (ui.properties?.[key] || {});
          const title = array ? (typeof ui.itemLabel === 'function' ? ui.itemLabel(Number(key), child) : typeof ui.itemLabel === 'string' ? `${ui.itemLabel} ${Number(key) + 1}` : `第 ${Number(key) + 1} 项`) : childSpec.title || key;
          const childNode = renderNode(entryPath, childSpec, childUi, depth + 1, title);
          if (array && typeof child === 'object' && child !== null) childNode.classList.add('cje-card');
          const childRow = childNode.firstChild;
          const actions = element('div', null, 'cje-actions');
          if (!array && !Object.hasOwn(spec.properties || {}, key)) {
            const rename = element('input', null, 'cje-key'); rename.value = key; rename.setAttribute('aria-label', '字段名');
            rename.disabled = config.readOnly; childRow.replaceChild(rename, childRow.firstChild);
            rename.addEventListener('input', () => {
              if (rename.value !== key) pendingKeys.set(pointer(entryPath), { path: entryPath, key: rename.value }); else pendingKeys.delete(pointer(entryPath));
              model.dirty = pendingKeys.size > 0 || model.draft !== model.baseline;
              if (!rename.value.trim() || (rename.value !== key && Object.hasOwn(getAt(model.value, path), rename.value))) fail(entryPath, '字段名为空或已存在'); else { localErrors.delete(pointer(entryPath)); announce(true); }
            });
            rename.addEventListener('change', () => {
              const nextKey = rename.value;
              if (!nextKey.trim() || (nextKey !== key && Object.hasOwn(value, nextKey))) return;
              if (localErrors.size) return;
              pendingKeys.delete(pointer(entryPath));
              const next = Object.fromEntries(Object.entries(getAt(model.value, path)).map(([entry, val]) => [entry === key ? nextKey : entry, val]));
              commit(path, next, true);
            });
          }
          if (array) {
            const move = (direction) => { const list = [...getAt(model.value, path)], from = Number(key), to = from + direction; if (to < 0 || to >= list.length) return; [list[from], list[to]] = [list[to], list[from]]; commit(path, list, true); };
            const up = button('↑', () => move(-1), '向上移动'), down = button('↓', () => move(1), '向下移动');
            up.disabled = config.readOnly || key === '0'; down.disabled = config.readOnly || Number(key) === value.length - 1; actions.append(up, down);
          }
          if (!array && spec.required?.includes(key)) childRow.firstChild.append(element('span', '*', 'cje-required'));
          else if (childUi.removable !== false && childSpec.ui?.removable !== false) { const remove = button('×', () => commit(entryPath, undefined, true, true), `删除 ${title}`); remove.className = 'cje-delete'; remove.disabled = config.readOnly; actions.append(remove); }
          if (actions.childNodes.length) childRow.append(actions);
          children.append(childNode);
        }
        if (!entries.length) children.append(element('span', array ? '暂无项目' : '暂无字段', 'cje-description'));
        if (!config.readOnly) {
          const add = element('div', null, 'cje-add');
          if (array) add.append(button('＋ 添加项', () => { const list = [...getAt(model.value, path)]; list.push(seed(spec.items || {}, ui.newItemType)); commit(path, list, true); }));
          else {
            const missing = Object.keys(spec.properties || {}).filter((key) => !Object.hasOwn(value, key));
            if (missing.length) {
              const select = element('select'); select.setAttribute('aria-label', '添加已定义字段');
              for (const key of missing) { const option = element('option', spec.properties[key].title || key); option.value = key; select.append(option); }
              add.append(select, button('添加字段', () => commit([...path, select.value], seed(spec.properties[select.value]), true)));
            }
            if (spec.additionalProperties !== false) {
              const key = element('input'); key.placeholder = '新字段名称'; key.setAttribute('aria-label', '新字段名称');
              const type = chooseType(typeof spec.additionalProperties === 'object' ? spec.additionalProperties : {}, 'string', () => {});
              const addKey = () => { if (!key.value.trim() || Object.hasOwn(value, key.value)) { fail(path, '字段名为空或已存在'); return; } localErrors.delete(pointer(path)); commit([...path, key.value], seed(ownSpec(spec, key.value), type.value), true); };
              key.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); addKey(); } }); add.append(key, type, button('添加', addKey));
            }
          }
          children.append(add);
        }
      }
      if (details.open) fill(); details.addEventListener('toggle', () => { if (details.open) fill(); });
    }
    return node;
  }
  function renderForm() {
    disposers.forEach((dispose) => dispose()); disposers = []; localErrors.clear();
    pendingKeys.clear();
    form.replaceChildren(renderNode([], model.schema, config.uiSchema || {}, 0, config.label || '值'));
  }
  function ensureView() {
    if (view) return;
    view = new EditorView({ parent: source, state: EditorState.create({ doc: model.draft, extensions: [json(), lineNumbers(), drawSelection(), highlightActiveLine(), history(), foldGutter(), bracketMatching(), syntaxHighlighting(defaultHighlightStyle), search(), lintGutter(), readOnlyCompartment.of([EditorState.readOnly.of(!!config.readOnly), EditorView.editable.of(!config.readOnly)]), keymap.of([{ key: 'Alt-Shift-f', run: () => { format(); return true; } }, ...defaultKeymap, indentWithTab, ...historyKeymap, ...searchKeymap, ...foldKeymap]), EditorView.updateListener.of((update) => { if (update.docChanged && !syncing) { localErrors.clear(); model.edit(update.state.doc.toString()); publish(); } }), EditorView.theme({ '&': { background: 'var(--cje-bg)', color: 'var(--cje-ink)' } })] }) });
  }
  function switchMode(next) {
    if (next === mode) return;
    if (next === 'form' && (!model.valid || localErrors.size)) { announce(); return; }
    if (next === 'json' && localErrors.size) { announce(); return; }
    if (next === 'json' && pendingKeys.size) { try { controller.getValue(); } catch { announce(); return; } }
    mode = next; form.hidden = next !== 'form'; source.hidden = next !== 'json';
    formTab.setAttribute('aria-selected', String(next === 'form')); sourceTab.setAttribute('aria-selected', String(next === 'json')); formatButton.hidden = next !== 'json';
    formTab.tabIndex = next === 'form' ? 0 : -1; sourceTab.tabIndex = next === 'json' ? 0 : -1;
    if (next === 'json') { ensureView(); syncSource(); view.requestMeasure(); } else renderForm(); announce();
  }
  function format() { if (!model.valid || config.readOnly) return; model.commit(model.value); syncSource(); publish(); }
  function showConflict() {
    conflict.hidden = !model.pending; conflict.replaceChildren();
    if (model.pending) conflict.append(element('span', '外部配置已更新。'), button('加载更新', () => { model.reset(model.pending); renderForm(); syncSource(); showConflict(); announce(); }), button('保留当前编辑', () => { model.pending = null; showConflict(); publish(); }));
  }
  function keydown(event) {
    if (event.key === 'Escape' && event.defaultPrevented) { event.stopPropagation(); return; }
    if (event.key === 'Escape' && !host.querySelector('.cm-search')) return;
    event.stopPropagation();
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault();
      if (!config.readOnly) try {
        const value = controller.getValue(); config.onSave?.(value);
        host.dispatchEvent(new doc.defaultView.CustomEvent('cwm-json-editor-save', { bubbles: true }));
      } catch { announce(); }
    }
    if (mode === 'form' && event.key === 'Enter' && event.target.tagName === 'INPUT') event.preventDefault();
  }
  tabs.addEventListener('keydown', (event) => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault(); switchMode(mode === 'form' ? 'json' : 'form');
    (mode === 'form' ? formTab : sourceTab).focus();
  });
  host.addEventListener('keydown', keydown);
  const controller = {
    get readOnly() { return !!config.readOnly; },
    getState: () => ({ ...model.state(), valid: model.valid && !localErrors.size, errors: allErrors(), mode, pendingKeys: [...pendingKeys.values()] }),
    getValue: () => {
      if (localErrors.size) { announce(); throw new Error([...localErrors.values()].map((issue) => issue.message).join('\n')); }
      if (pendingKeys.size) {
        let value = model.value;
        for (const { path, key } of [...pendingKeys.values()].sort((a, b) => b.path.length - a.path.length)) {
          const parent = path.slice(0, -1), old = path.at(-1), object = getAt(value, parent);
          if (!key.trim() || (key !== old && Object.hasOwn(object, key))) throw new Error('字段名为空或已存在');
          value = setAt(value, parent, Object.fromEntries(Object.entries(object).map(([entry, next]) => [entry === old ? key : entry, next])));
        }
        model.commit(value); renderForm(); syncSource(); publish();
      }
      const value = model.getValue(); announce(); return value;
    },
    setOptions(next) {
      const readChanged = Object.hasOwn(next, 'readOnly') && config.readOnly !== next.readOnly;
      const shapeChanged = (next.schema && next.schema !== model.schema) || (Object.hasOwn(next, 'uiSchema') && next.uiSchema !== config.uiSchema);
      config = { ...config, ...next };
      if (next.schema) model.schema = next.schema;
      model.customValidate = config.validate;
      model.check();
      if (Object.hasOwn(next, 'text') || Object.hasOwn(next, 'value')) { if (model.external(next)) { renderForm(); syncSource(); } showConflict(); }
      if (readChanged) { view?.dispatch({ effects: readOnlyCompartment.reconfigure([EditorState.readOnly.of(!!config.readOnly), EditorView.editable.of(!config.readOnly)]) }); renderForm(); }
      else if (shapeChanged && mode === 'form' && !localErrors.size && !pendingKeys.size) renderForm();
      announce();
    },
    setDraft(text) { if (config.readOnly) return; localErrors.clear(); pendingKeys.clear(); model.edit(text); syncSource(); if (mode === 'form' && !model.valid) switchMode('json'); else if (mode === 'form') renderForm(); publish(); },
    markSaved() { model.baseline = model.draft; model.dirty = false; model.pending = null; showConflict(); announce(); },
    switchMode,
    destroy() { if (destroyed) return; destroyed = true; view?.destroy(); disposers.forEach((dispose) => dispose()); host.removeEventListener('keydown', keydown); delete host._cwmJsonEditor; host.replaceChildren(); },
  };
  host._cwmJsonEditor = controller;
  renderForm(); const initial = mode; mode = null; switchMode(initial);
  return controller;
}
