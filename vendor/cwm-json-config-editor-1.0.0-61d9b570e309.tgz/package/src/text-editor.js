import stylesheet from './form-controls.css';

export function installFormControlStyles(doc) {
  if (doc.getElementById('cwm-form-controls-style')) return;
  const style = doc.createElement('style'); style.id = 'cwm-form-controls-style'; style.textContent = stylesheet; doc.head.append(style);
}

/** A plain-text control shared by React, schema forms and backend inspectors. */
export function createMultilineEditor({ input, document: owner, value = '', label = '文本', readOnly = false, rows = 6, placeholder = '', onChange, getCopyValue } = {}) {
  const doc = input?.ownerDocument || owner || globalThis.document;
  installFormControlStyles(doc);
  const make = (tag, className, text) => { const node = doc.createElement(tag); if (className) node.className = className; if (text != null) node.textContent = text; return node; };
  const root = make('div', 'cwm-text-editor'), toolbar = make('div', 'cwm-text-toolbar'), title = make('span', 'cwm-text-title', label);
  const actions = make('div', 'cwm-text-actions'), count = make('small', 'cwm-text-count'), status = make('span', 'cwm-text-status');
  const content = input || make(readOnly ? 'div' : 'textarea');
  const isTextarea = content.tagName === 'TEXTAREA';
  let config = { label, readOnly, rows, placeholder, onChange, getCopyValue }, destroyed = false, timer;
  const getValue = () => isTextarea ? content.value : content.textContent;
  const clearFeedback = () => { clearTimeout(timer); status.textContent = ''; delete status.dataset.state; copy.textContent = '复制'; };
  const makeButton = (text, callback) => { const button = make('button', '', text); button.type = 'button'; button.addEventListener('click', callback); return button; };
  const selectAll = () => {
    content.focus({ preventScroll: true });
    if (isTextarea) content.select();
    else { const range = doc.createRange(); range.selectNodeContents(content); const selection = doc.defaultView.getSelection(); selection.removeAllRanges(); selection.addRange(range); }
  };
  const copy = makeButton('复制', async () => {
    const text = config.getCopyValue ? config.getCopyValue() : getValue();
    try {
      if (doc.defaultView.navigator.clipboard?.writeText) await doc.defaultView.navigator.clipboard.writeText(text);
      else { selectAll(); if (!doc.execCommand?.('copy')) throw new Error('复制不可用'); }
      if (destroyed || (config.getCopyValue ? config.getCopyValue() : getValue()) !== text) return;
      status.dataset.state = 'success'; status.textContent = '已复制'; copy.textContent = '已复制';
    } catch { if (!destroyed) { status.dataset.state = 'error'; status.textContent = '复制不可用，请全选后复制'; selectAll(); } }
    if (!destroyed) { clearTimeout(timer); timer = setTimeout(clearFeedback, 1800); }
  });
  const select = makeButton('全选', selectAll);
  status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  actions.append(count, select, copy); toolbar.append(title, actions); root.append(toolbar, content, status);
  content.classList.add('cwm-text-content', 'pretty-scrollbar');
  if (!isTextarea) { content.tabIndex = 0; content.setAttribute('role', 'textbox'); content.setAttribute('aria-multiline', 'true'); content.setAttribute('aria-readonly', 'true'); }
  function refresh() {
    const text = getValue(); count.textContent = `${Array.from(text).length.toLocaleString()} 字符`;
    copy.disabled = !(config.getCopyValue ? config.getCopyValue() : text); select.disabled = !text;
    root.dataset.readonly = String(config.readOnly || !isTextarea);
    title.textContent = config.label; copy.setAttribute('aria-label', `复制${config.label}`); select.setAttribute('aria-label', `全选${config.label}`);
    if (!content.hasAttribute('aria-label')) content.setAttribute('aria-label', config.label);
  }
  const change = event => { clearFeedback(); refresh(); config.onChange?.(getValue(), event); };
  content.addEventListener('input', change);
  const api = {
    root, input: content, getValue, selectAll,
    setOptions(next = {}) {
      config = { ...config, ...next };
      if (Object.hasOwn(next, 'value')) { const text = String(next.value ?? ''); if (getValue() !== text) { clearFeedback(); if (isTextarea) content.value = text; else content.textContent = text; } }
      if (isTextarea) { content.readOnly = Boolean(config.readOnly); content.rows = config.rows; content.placeholder = config.placeholder; }
      refresh();
    },
    destroy() { if (destroyed) return; destroyed = true; clearTimeout(timer); content.removeEventListener('input', change); root.remove(); },
  };
  api.setOptions({ value: input ? getValue() : value });
  root._cwmTextEditor = api;
  return api;
}
