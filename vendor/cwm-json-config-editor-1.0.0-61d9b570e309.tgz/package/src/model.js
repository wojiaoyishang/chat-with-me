import Ajv from 'ajv';
import { parseTree, printParseErrorCode } from 'jsonc-parser';

const ajv = new Ajv({ allErrors: true, strict: false, validateFormats: false, ownProperties: true });
const validators = new WeakMap();
const syntaxMessages = {
  InvalidSymbol: '存在无效符号', InvalidNumberFormat: '数字格式错误', PropertyNameExpected: '字段名称需要双引号', ValueExpected: '缺少值', ColonExpected: '缺少冒号', CommaExpected: '缺少逗号', CloseBraceExpected: '缺少右花括号', CloseBracketExpected: '缺少右方括号', EndOfFileExpected: 'JSON 值后存在多余内容', InvalidCommentToken: 'JSON 不支持注释', UnexpectedEndOfComment: '注释未结束', UnexpectedEndOfString: '文本缺少结束引号', UnexpectedEndOfNumber: '数字尚未填写完整', InvalidUnicode: 'Unicode 转义格式错误', InvalidEscapeCharacter: '转义字符错误', InvalidCharacter: '存在无效字符',
};
export const types = ['string', 'number', 'boolean', 'null', 'object', 'array'];
export const pointer = (path) => '/' + path.map((key) => String(key).replace(/~/g, '~0').replace(/\//g, '~1')).join('/');
export const kind = (value) => value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
export const clone = (value) => JSON.parse(JSON.stringify(value));
export function seed(schema = {}, type = undefined) {
  if (Object.hasOwn(schema, 'default') && schema.default !== undefined) return clone(schema.default);
  if (schema.enum?.length) return clone(schema.enum[0]);
  const chosen = type || (Array.isArray(schema.type) ? schema.type[0] : schema.type) || 'string';
  if (chosen === 'array') return [];
  if (chosen === 'object') return Object.fromEntries(Object.entries(schema.properties || {})
    .filter(([key, spec]) => schema.required?.includes(key) || Object.hasOwn(spec, 'default'))
    .map(([key, spec]) => [key, seed(spec)]));
  return { string: '', number: 0, integer: 0, boolean: false, null: null }[chosen] ?? '';
}
export function getAt(value, path) { return path.reduce((current, key) => current?.[key], value); }
export function setAt(value, path, next, remove = false) {
  if (!path.length) return next;
  const [key, ...rest] = path;
  const result = Array.isArray(value) ? [...value] : { ...value };
  if (rest.length) Object.defineProperty(result, key, { value: setAt(result[key], rest, next, remove), enumerable: true, configurable: true, writable: true });
  else if (remove) Array.isArray(result) ? result.splice(key, 1) : delete result[key];
  else Object.defineProperty(result, key, { value: next, enumerable: true, configurable: true, writable: true });
  return result;
}
export function inspectValue(value, path = [], depth = 0) {
  if (depth > 40) return [{ path: pointer(path), message: '嵌套层级超过 40 层' }];
  if (typeof value === 'number' && (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))))
    return [{ path: pointer(path), message: '数字必须有限；超出安全范围的整数请使用字符串' }];
  if (value && typeof value === 'object') return Object.entries(value).flatMap(([key, child]) => inspectValue(child, [...path, key], depth + 1));
  if (!['string', 'number', 'boolean', 'object'].includes(typeof value)) return [{ path: pointer(path), message: '不是合法的 JSON 值' }];
  return [];
}
export function validate(value, schema = {}) {
  const errors = inspectValue(value);
  try {
    let check = validators.get(schema);
    if (!check) { check = ajv.compile(schema); validators.set(schema, check); }
    if (!check(value)) for (const issue of check.errors || []) errors.push({
      path: issue.instancePath + (issue.keyword === 'required' ? pointer([issue.params.missingProperty]) : ''),
      message: ({ type: `需要 ${issue.params.type} 类型`, required: '必填字段未填写', additionalProperties: `不允许字段 ${issue.params.additionalProperty}`, enum: '请选择允许的值', minimum: `不得小于 ${issue.params.limit}`, maximum: `不得大于 ${issue.params.limit}`, minLength: `至少 ${issue.params.limit} 个字符`, maxLength: `最多 ${issue.params.limit} 个字符`, minItems: `至少 ${issue.params.limit} 项`, maxItems: `最多 ${issue.params.limit} 项`, uniqueItems: '列表存在重复项' })[issue.keyword] || issue.message,
    });
  } catch { errors.push({ path: '', message: '字段配置无效，无法完成校验' }); }
  return errors;
}
export function parse(text, schema = {}, maxLength = 1000000) {
  if (text.length > maxLength) return { errors: [{ path: '', offset: 0, message: `内容超过 ${maxLength} 个字符` }] };
  let depth = 0, inString = false, escaped = false;
  for (let index = 0; index < text.length; index++) {
    const char = text[index];
    if (inString) { if (escaped) escaped = false; else if (char === '\\') escaped = true; else if (char === '"') inString = false; }
    else if (char === '"') inString = true;
    else if (char === '{' || char === '[') { if (++depth > 40) return { errors: [{ path: '', offset: index, message: '嵌套层级超过 40 层' }] }; }
    else if (char === '}' || char === ']') depth--;
  }
  const syntax = [];
  const tree = parseTree(text, syntax, { allowTrailingComma: false, disallowComments: true });
  if (syntax.length || !tree) return { errors: syntax.length ? syntax.map((issue) => ({ path: '', offset: issue.offset, message: `JSON 格式错误：${syntaxMessages[printParseErrorCode(issue.error)] || printParseErrorCode(issue.error)}` })) : [{ path: '', offset: 0, message: '请输入 JSON 值' }] };
  const errors = [];
  function check(node, path = [], depth = 0) {
    if (depth > 40) { errors.push({ path: pointer(path), offset: node.offset, message: '嵌套层级超过 40 层' }); return; }
    if (node.type === 'object') {
      const keys = new Set();
      for (const property of node.children || []) {
        const key = property.children[0].value;
        if (keys.has(key)) errors.push({ path: pointer([...path, key]), offset: property.offset, message: `字段 ${key} 重复` });
        keys.add(key); check(property.children[1], [...path, key], depth + 1);
      }
    } else if (node.type === 'array') node.children?.forEach((child, index) => check(child, [...path, index], depth + 1));
  }
  check(tree);
  // JSON.parse preserves own keys such as __proto__; assigning them must never alter prototypes.
  const value = JSON.parse(text);
  return { value, tree, errors: [...errors, ...validate(value, schema)] };
}
export function nodeOffset(tree, path) {
  let node = tree;
  for (const part of path) {
    if (node?.type === 'object') node = node.children?.find((property) => property.children[0].value === part)?.children[1];
    else if (node?.type === 'array') node = node.children?.[Number(part)];
    else return 0;
  }
  return node?.offset || 0;
}

export class EditorModel {
  constructor(options = {}) {
    this.schema = options.schema || {};
    this.maxLength = options.maxLength || 1000000;
    this.customValidate = options.validate;
    this.value = options.value === undefined ? seed(this.schema) : clone(options.value);
    this.draft = options.text ?? JSON.stringify(this.value, null, 2);
    this.baseline = this.draft;
    this.previousExternal = options.text ?? JSON.stringify(this.value);
    this.dirty = false;
    this.check();
  }
  check() {
    const result = parse(this.draft, this.schema, this.maxLength);
    this.tree = result.tree;
    this.errors = result.errors;
    if (!this.errors.length && this.customValidate) this.errors.push(...(this.customValidate(result.value) || []));
    this.valid = !this.errors.length;
    if (Object.hasOwn(result, 'value')) this.value = result.value;
    return this.state();
  }
  edit(text) { this.draft = text; this.dirty = text !== this.baseline; return this.check(); }
  commit(value) { return this.edit(JSON.stringify(value, null, 2)); }
  external(options) {
    const incoming = options.text ?? JSON.stringify(options.value);
    if (incoming === this.previousExternal || incoming === this.draft || (!options.text && incoming === JSON.stringify(this.value))) { this.previousExternal = incoming; return false; }
    this.previousExternal = incoming;
    if (this.dirty) { this.pending = options; return false; }
    this.reset(options); return true;
  }
  reset(options) {
    if (options.value !== undefined) this.value = clone(options.value);
    this.draft = options.text ?? JSON.stringify(this.value, null, 2);
    this.baseline = this.draft; this.previousExternal = options.text ?? JSON.stringify(this.value);
    this.pending = null; this.dirty = false; this.check();
  }
  state() { return { valid: this.valid, dirty: this.dirty, errors: this.errors, draft: this.draft, value: this.value }; }
  getValue() { this.check(); if (!this.valid) throw new Error(this.errors.map((error) => `${error.path || 'JSON'}：${error.message}`).join('\n')); return clone(this.value); }
}
